# Trello

<h3>Tech Stacks:</h3>

- Kotlin
- Koin()
- RxJAndroid
- Retrofit
- Android architecture components(ViewModel,LiveData)
- MVVM(Clean  architecture)
