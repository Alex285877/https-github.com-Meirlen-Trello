package com.example.meirlen.mtrello.base.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}