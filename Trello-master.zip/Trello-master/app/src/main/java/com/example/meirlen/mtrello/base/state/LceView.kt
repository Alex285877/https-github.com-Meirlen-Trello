package com.example.meirlen.mtrello.base.state

interface LceView {
    fun changeState(state: LceLayout.LceState)
}