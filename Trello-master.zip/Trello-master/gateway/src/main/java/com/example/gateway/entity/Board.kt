package com.example.gateway.entity



data class Board(val id: String, val name: String)